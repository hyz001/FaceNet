# coding=utf-8
"""Performs face detection in realtime.

Based on code from https://github.com/shanren7/real_time_face_recognition
"""
# MIT License
#
# Copyright (c) 2017 François Gervais
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
import tensorflow as tf

import cv2
import os
import facenet
from scipy import misc
# filename = "2.png"
# img = cv2.imread(filename,1)
# print (img)
# cv2.namedWindow('inputaa', 0)
# cv2.imshow('inputaa', img)
#
# with tf.Graph().as_default():
#     with tf.Session() as sess:
#         height, width = img.shape[:2]
#         cropped_image = tf.random_crop(img, (160, 160, 3))
#         # cv2.namedWindow('output', 0)
#         # cv2.imwrite()
#         cv2.imshow("output", cropped_image.eval())
#         # for x in range(12):
#         #     cropped_image = tf.random_crop(img, (height / 4, width / 4, 3))
#         #     cv2.imshow("output" + str(x), cropped_image.eval())
#         cv2.waitKey(0)
#         sess.close()

nrof_images_total = 0
input_dir = "E:\\colect-face\\aligncrop"
output_dir =  "E:\\colect-face\\aligncrop-160"
dataset = facenet.get_dataset(input_dir)
for cls in dataset:
    output_class_dir = os.path.join(output_dir, cls.name)
    if not os.path.exists(output_class_dir):
        os.makedirs(output_class_dir)
    for image_path in cls.image_paths:
        nrof_images_total += 1
        print(nrof_images_total)
        filename = os.path.splitext(os.path.split(image_path)[1])[0]
        output_filename = os.path.join(output_class_dir, filename + '.png')
        print(image_path)
        if not os.path.exists(output_filename):
            try:
                img = cv2.imread(image_path)
            except (IOError, ValueError, IndexError) as e:
                errorMessage = '{}: {}'.format(image_path, e)
                print(errorMessage)
            else:
                # if img.ndim < 2:
                #     print('Unable to align "%s"' % image_path)
                #     # text_file.write('%s\n' % (output_filename))
                #     continue
                # if img.ndim == 2:
                #     img = facenet.to_rgb(img)
                img = img[:, :, 0:3]
                scaled = misc.imresize(img, (160, 160), interp='bilinear')
                # scaled = cv2.resize(img,(160,160),interpolation=cv2.INTER_CUBIC)
                cv2.imwrite(output_filename, scaled)
                # results = align.detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
