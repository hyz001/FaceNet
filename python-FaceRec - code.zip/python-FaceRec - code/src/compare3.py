"""Performs face alignment and calculates L2 distance between the embeddings of images."""

# MIT License
# 
# Copyright (c) 2016 David Sandberg
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy
import pickle
import time
from scipy import misc
import tensorflow as tf
import numpy as np
import sys
import os
import argparse
import cv2
import math
import facenet
import align.detect_face


def main():
    # model = "20180131-175730/20180131-175730.pb"#直接加载pb快很多啊
    model = "20180612-155404/99w_train.pb"
    traindata_path = "../data/hu2"
    image_files = []
    face_label = []
    for images in os.listdir(traindata_path):
        print(traindata_path + "/" + images)
        filename = os.path.splitext(os.path.split(images)[1])[0]
        face_label.append(filename)
        # print(filename)
        image_files.append(traindata_path + "/" + images)
    # image_files = ["../data/images/4.jpg","../data/images/11.jpg","../data/images/2.jpg","../data/images/5.jpg"
    #     , "../data/images/6.jpg"]
    image_size = 160
    margin = 32
    gpu_memory_fraction = 1.0
    images, face_label_list = load_and_align_data(image_files, face_label, image_size, margin, gpu_memory_fraction)
    with tf.Graph().as_default():

        with tf.Session() as sess:

            # Load the model
            facenet.load_model(model)  # load model超级费时间
            print('time:')
            start_time = time.time()
            # Get input and output tensors
            images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
            embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
            phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")

            # Run forward pass to calculate embeddings
            feed_dict = {images_placeholder: images, phase_train_placeholder: False}
            emb = sess.run(embeddings, feed_dict=feed_dict)
            print(emb)
            # face_label = []
            # face_label.append("hu")
            # face_label.append("reba")
            # face_label.append("kong")
            # face_label.append("tongshi")
            # face_label.append("lixiaolong")
            # 测试函数,四个点原来是取奇数和偶数列
            # embeddings_demo = [0,2,3,4,5,6]
            # embeddings11 = embeddings_demo[0::2]
            # embeddings22 = embeddings_demo[1::2]
            # print(embeddings11)
            # print('shit')
            # print(embeddings22)
            write_file = open('knn_classifier.pkl', 'wb')
            pickle.dump(emb, write_file, -1)
            pickle.dump(face_label_list, write_file, -1)
            write_file.close()
            end_time = time.time()
            print((end_time - start_time))  # 为提取的向量特征128维，存储在数组中
            nrof_images = len(image_files)
            print('Images:')
            for i in range(nrof_images):
                print('%1d: %s' % (i, image_files[i]))
            print('')

            # Print distance matrix
            print('Distance matrix')
            print('    ', end='')
            for i in range(nrof_images):
                print('    %1d     ' % i, end='')
            print('')
            for i in range(nrof_images):
                print('%1d  ' % i, end='')
                for j in range(nrof_images):
                    # dist = np.sqrt(np.sum(np.square(np.subtract(emb[i,:], emb[j,:]))))
                    num = np.dot(emb[i, :], emb[j, :])
                    denom = np.linalg.norm(emb[i, :]) * np.linalg.norm(emb[j, :])
                    cos = num / denom  # 余弦值
                    cossim = 0.5 + 0.5 * cos  # 归一化，，余弦距离
                    print('  %1.4f  ' % cossim, end='')
                print('')
            X = [1, 2, 3, 4]
            # '列表转换为数组'
            Y = np.array(X)
            print(Y)
            print('list is:')
            Z = []
            Z.append(5)
            Z.append(6)
            Z.append(7)
            print(Z)
            print('list to array is:')
            M = np.array(Z)
            print(M)


def load_and_align_data(image_paths, face_label, image_size, margin, gpu_memory_fraction):
    face_label_list = []
    num = 0
    minsize = 20  # minimum size of face
    threshold = [0.6, 0.7, 0.7]  # three steps's threshold
    factor = 0.709  # scale factor

    print('Creating networks and loading parameters')
    with tf.Graph().as_default():
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=gpu_memory_fraction)
        sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=False))
        with sess.as_default():
            pnet, rnet, onet = align.detect_face.create_mtcnn(sess, None)

    tmp_image_paths = image_paths.copy()
    tmp_face_label = face_label
    # filename = os.path.splitext(os.path.split(tmp_image_paths)[1])[0]
    # print(filename)
    img_list = []
    for image in tmp_image_paths:
        img = misc.imread(os.path.expanduser(image), mode='RGB')
        img_size = np.asarray(img.shape)[0:2]
        bounding_boxes, _ = align.detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
        if len(bounding_boxes) < 1:
            image_paths.remove(image)
            num = num + 1
            print("can't detect face, remove ", image)
            continue
        for face_position in bounding_boxes:
            face_position = face_position.astype(int)
            cv2.rectangle(img, (face_position[0],
                                face_position[1]),
                          (face_position[2], face_position[3]),
                          (0, 255, 0), 2)
        # cv2.imwrite("video.jpg", img)
        det = np.squeeze(bounding_boxes[0, 0:4])
        bb = np.zeros(4, dtype=np.int32)
        bb[0] = np.maximum(det[0] - margin / 2, 0)
        bb[1] = np.maximum(det[1] - margin / 2, 0)
        bb[2] = np.minimum(det[2] + margin / 2, img_size[1])
        bb[3] = np.minimum(det[3] + margin / 2, img_size[0])
        cropped = img[bb[1]:bb[3], bb[0]:bb[2], :]
        # cv2.imwrite("videos.jpg", cropped)
        aligned = misc.imresize(cropped, (image_size, image_size), interp='bilinear')
        # cv2.imwrite("videoss.jpg", aligned)
        prewhitened = facenet.prewhiten(aligned)
        img_list.append(prewhitened)
        face_label_list.append(tmp_face_label[num])
        num = num + 1
    images = np.stack(img_list)
    print(num)
    return images, face_label_list


if __name__ == '__main__':
    main()
