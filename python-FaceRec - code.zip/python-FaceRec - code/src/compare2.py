"""Performs face alignment and calculates L2 distance between the embeddings of images."""

# MIT License
# 
# Copyright (c) 2016 David Sandberg
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy
import pickle
import time
from scipy import misc
import tensorflow as tf
import numpy as np
import sys
import os
import argparse
import cv2
import math
import facenet
import align.detect_face
def list2colmatrix( pts_list):
    """
        convert list to column matrix
    Parameters:
    ----------
        pts_list:
            input list
    Retures:
    -------
        colMat:
    """
    assert len(pts_list) > 0
    colMat = []
    for i in range(len(pts_list)):
        colMat.append(pts_list[i][0])
        colMat.append(pts_list[i][1])
    colMat = np.matrix(colMat).transpose()
    return colMat

def find_tfrom_between_shapes( from_shape, to_shape):
    """
        find transform between shapes
    Parameters:
    ----------
        from_shape:
        to_shape:
    Retures:
    -------
        tran_m:
        tran_b:
    """
    assert from_shape.shape[0] == to_shape.shape[0] and from_shape.shape[0] % 2 == 0

    sigma_from = 0.0
    sigma_to = 0.0
    cov = np.matrix([[0.0, 0.0], [0.0, 0.0]])

    # compute the mean and cov
    from_shape_points = from_shape.reshape(int(from_shape.shape[0] / 2), 2)
    to_shape_points = to_shape.reshape(int(to_shape.shape[0] / 2), 2)
    mean_from = from_shape_points.mean(axis=0)
    mean_to = to_shape_points.mean(axis=0)

    for i in range(from_shape_points.shape[0]):
        temp_dis = np.linalg.norm(from_shape_points[i] - mean_from)
        sigma_from += temp_dis * temp_dis
        temp_dis = np.linalg.norm(to_shape_points[i] - mean_to)
        sigma_to += temp_dis * temp_dis
        cov += (to_shape_points[i].transpose() - mean_to.transpose()) * (from_shape_points[i] - mean_from)

    sigma_from = sigma_from / to_shape_points.shape[0]
    sigma_to = sigma_to / to_shape_points.shape[0]
    cov = cov / to_shape_points.shape[0]

    # compute the affine matrix
    s = np.matrix([[1.0, 0.0], [0.0, 1.0]])
    u, d, vt = np.linalg.svd(cov)

    if np.linalg.det(cov) < 0:
        if d[1] < d[0]:
            s[1, 1] = -1
        else:
            s[0, 0] = -1
    r = u * s * vt
    c = 1.0
    if sigma_from != 0:
        c = 1.0 / sigma_from * np.trace(np.diag(d) * s)

    tran_b = mean_to.transpose() - c * r * mean_from.transpose()
    tran_m = c * r

    return tran_m, tran_b
def extract_image_chips(img, points, desired_size=256, padding=0):
    """
        crop and align face
    Parameters:
    ----------
        img: numpy array, bgr order of shape (1, 3, n, m)
            input image
        points: numpy array, n x 10 (x1, x2 ... x5, y1, y2 ..y5)
        desired_size: default 256
        padding: default 0
    Retures:
    -------
        crop_imgs: list, n
            cropped and aligned faces
    """
    print(points)
    crop_imgs = []
    for p in points:
        shape = []
        # print(len(p))
        # print(int(len(p)/2))
        for k in range(int(len(p)/2)):
            shape.append(p[k])
            shape.append(p[k + 5])

        if padding > 0:
            padding = padding
        else:
            padding = 0
        # average positions of face points
        mean_face_shape_x = [0.224152, 0.75610125, 0.490127, 0.254149, 0.726104]
        mean_face_shape_y = [0.2119465, 0.2119465, 0.628106, 0.780233, 0.780233]

        from_points = []
        to_points = []

        for i in range(int(len(shape) / 2)):
            x = (padding + mean_face_shape_x[i]) / (2 * padding + 1) * desired_size
            y = (padding + mean_face_shape_y[i]) / (2 * padding + 1) * desired_size
            to_points.append([x, y])
            from_points.append([shape[2 * i], shape[2 * i + 1]])

        # convert the points to Mat
        from_mat = list2colmatrix(from_points)
        to_mat = list2colmatrix(to_points)

        # compute the similar transfrom
        tran_m, tran_b = find_tfrom_between_shapes(from_mat, to_mat)

        probe_vec = np.matrix([1.0, 0.0]).transpose()
        probe_vec = tran_m * probe_vec

        scale = np.linalg.norm(probe_vec)
        angle = 180.0 / math.pi * math.atan2(probe_vec[1, 0], probe_vec[0, 0])

        from_center = [(shape[0] + shape[2]) / 2.0, (shape[1] + shape[3]) / 2.0]
        to_center = [0, 0]
        to_center[1] = desired_size * 0.4
        to_center[0] = desired_size * 0.5

        ex = to_center[0] - from_center[0]
        ey = to_center[1] - from_center[1]

        rot_mat = cv2.getRotationMatrix2D((from_center[0], from_center[1]), -1 * angle, scale)
        rot_mat[0][2] += ex
        rot_mat[1][2] += ey

        chips = cv2.warpAffine(img, rot_mat, (desired_size, desired_size))
        crop_imgs.append(chips)
        cv2.imwrite("videos.jpg", chips[0])
    return crop_imgs
def main():
    # model = "20180131-175730/20180131-175730.pb"#直接加载pb快很多啊
    model = "20180315-121551"
    traindata_path = "../data/gump"
    image_files = []
    face_label = []
    for images in os.listdir(traindata_path):
        print(traindata_path + "/" + images)
        # filename = os.path.splitext(os.path.split(images)[1])[0]
        face_label.append(images)
        # print(filename)
        image_files.append(traindata_path + "/" + images)
    # image_files = ["../data/images/4.jpg","../data/images/11.jpg","../data/images/2.jpg","../data/images/5.jpg"
    #     , "../data/images/6.jpg"]
    image_size = 160
    margin = 40
    gpu_memory_fraction = 1.0
    images = load_and_align_data(image_files,image_size, margin, gpu_memory_fraction)
    with tf.Graph().as_default():

        with tf.Session() as sess:
      
            # Load the model
            facenet.load_model(model)#load model超级费时间
            print('time:')
            start_time = time.time()
            # Get input and output tensors
            images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
            embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
            phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")

            # Run forward pass to calculate embeddings
            feed_dict = { images_placeholder: images, phase_train_placeholder:False }
            emb = sess.run(embeddings, feed_dict=feed_dict)
            print(emb)
            # face_label = []
            # face_label.append("hu")
            # face_label.append("reba")
            # face_label.append("kong")
            # face_label.append("tongshi")
            # face_label.append("lixiaolong")
            #测试函数,四个点原来是取奇数和偶数列
            # embeddings_demo = [0,2,3,4,5,6]
            # embeddings11 = embeddings_demo[0::2]
            # embeddings22 = embeddings_demo[1::2]
            # print(embeddings11)
            # print('shit')
            # print(embeddings22)
            write_file = open('knn_classifier.pkl', 'wb')
            pickle.dump(emb, write_file, -1)
            pickle.dump(face_label, write_file, -1)
            write_file.close()
            end_time = time.time()
            print((end_time - start_time))#为提取的向量特征128维，存储在数组中
            nrof_images = len(image_files)
            print('Images:')
            for i in range(nrof_images):
                print('%1d: %s' % (i, image_files[i]))
            print('')
            
            # Print distance matrix
            print('Distance matrix')
            print('    ', end='')
            for i in range(nrof_images):
                print('    %1d     ' % i, end='')
            print('')
            for i in range(nrof_images):
                print('%1d  ' % i, end='')
                for j in range(nrof_images):
                    # dist = np.sqrt(np.sum(np.square(np.subtract(emb[i,:], emb[j,:]))))
                    num = np.dot(emb[i,:], emb[j,:])
                    denom = np.linalg.norm(emb[i,:]) * np.linalg.norm(emb[j,:])
                    cos = num / denom  # 余弦值
                    cossim = 0.5 + 0.5 * cos  # 归一化，，余弦距离
                    print('  %1.4f  ' % cossim, end='')
                print('')
            X = [1, 2, 3, 4]
            #'列表转换为数组'
            Y = np.array(X)
            print(Y)
            print('list is:')
            Z = []
            Z.append(5)
            Z.append(6)
            Z.append(7)
            print(Z)
            print('list to array is:')
            M = np.array(Z)
            print(M)



def load_and_align_data(image_paths, image_size, margin, gpu_memory_fraction):

    minsize = 20 # minimum size of face
    threshold = [ 0.6, 0.7, 0.7 ]  # three steps's threshold
    factor = 0.709 # scale factor
    
    print('Creating networks and loading parameters')
    with tf.Graph().as_default():
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=gpu_memory_fraction)
        sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=False))
        with sess.as_default():
            pnet, rnet, onet = align.detect_face.create_mtcnn(sess, None)
  
    tmp_image_paths = image_paths.copy()
    img_list = []
    for image in tmp_image_paths:
        img = misc.imread(os.path.expanduser(image), mode='RGB')
        img_size = np.asarray(img.shape)[0:2]
        results = align.detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
        bounding_boxes = results[0]
        points = results[1]
        points = points.T
        points = points.astype(np.int32)
        nrof_faces = bounding_boxes.shape[0]
        if nrof_faces > 0:
            # print(points)
            det = bounding_boxes[:, 0:4]
            det_arr = []
            img_size = np.asarray(img.shape)[0:2]
            # img_cv = cv2.imread(image_path)
            chips = extract_image_chips(img, points, 160, 0.37)
            cv2.imwrite("video2.jpg", chips[0])
            det_arr.append(np.squeeze(det))
            for i, det in enumerate(det_arr):
                prewhitened = facenet.prewhiten(chips[0])
                # print("ALI")
                # print(prewhitened)
                img_list.append(prewhitened)
                cv2.imwrite("videoss.jpg", chips[0])

    images = np.stack(img_list)
    return images

# def parse_arguments(argv):
#     parser = argparse.ArgumentParser()
#
#     parser.add_argument('model', type=str,
#         help='Could be either a directory containing the meta_file and ckpt_file or a model protobuf (.pb) file')
#     parser.add_argument('image_files', type=str, nargs='+', help='Images to compare')
#     parser.add_argument('--image_size', type=int,
#         help='Image size (height, width) in pixels.', default=160)
#     parser.add_argument('--margin', type=int,
#         help='Margin for the crop around the bounding box (height, width) in pixels.', default=44)
#     parser.add_argument('--gpu_memory_fraction', type=float,
#         help='Upper bound on the amount of GPU memory that will be used by the process.', default=1.0)
#     return parser.parse_args(argv)

if __name__ == '__main__':
    main()
