import os


def file_name(file_dir):
    dirs = os.listdir(file_dir)#files表示文件名，dirs可以表示为文件夹的名字
    for dir in dirs:
        print(dir)
        for root, dirs, files in os.walk(file_dir + '\\' + dir):
            num = 0
            print(files)
            for file in files:
                # 设置旧文件名（就是路径+文件名）
                oldname = file_dir + '\\' + dir + '\\'+ file
                print(oldname)
                newname = file_dir + '\\' + dir + '\\'+ str(num) + '.jpg'
                print(newname)
                num = num + 1
                # 用os模块中的rename方法对文件改名
                os.rename(oldname, newname)
                print(oldname, '======>', newname)
data_dir = '../data/facetest'
file_name(data_dir)