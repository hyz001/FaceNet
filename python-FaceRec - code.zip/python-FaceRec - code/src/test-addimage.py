# coding=utf-8
"""Performs face detection in realtime.

Based on code from https://github.com/shanren7/real_time_face_recognition
"""
# MIT License
#
# Copyright (c) 2017 François Gervais
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
import tensorflow as tf

import cv2
import os
import facenet
from scipy import misc
import numpy as np
import random
from PIL import Image, ImageEnhance
# filename = "2.png"
# img = cv2.imread(filename,1)
# print (img)
# cv2.namedWindow('inputaa', 0)
# cv2.imshow('inputaa', img)
#
# with tf.Graph().as_default():
#     with tf.Session() as sess:
#         height, width = img.shape[:2]
#         cropped_image = tf.random_crop(img, (160, 160, 3))
#         # cv2.namedWindow('output', 0)
#         # cv2.imwrite()
#         cv2.imshow("output", cropped_image.eval())
#         # for x in range(12):
#         #     cropped_image = tf.random_crop(img, (height / 4, width / 4, 3))
#         #     cv2.imshow("output" + str(x), cropped_image.eval())
#         cv2.waitKey(0)
#         sess.close()

nrof_images_total = 0
input_dir = "J:/data augmentation/abcdf_bb_add_78w-160"
output_dir =  "J:/data augmentation/abcdf_bb_add_78w-160"
dataset = facenet.get_dataset(input_dir)
# 定义旋转rotate函数
def rotate(image, angle, center=None, scale=1.0):
    # 获取图像尺寸
    (h, w) = image.shape[:2]

    # 若未指定旋转中心，则将图像中心设为旋转中心
    if center is None:
        center = (w / 2, h / 2)

    # 执行旋转
    M = cv2.getRotationMatrix2D(center, angle, scale)
    rotated = cv2.warpAffine(image, M, (w, h))

    # 返回旋转后的图像
    return rotated
for cls in dataset:
    output_class_dir = os.path.join(output_dir, cls.name)
    if not os.path.exists(output_class_dir):
        os.makedirs(output_class_dir)
    for image_path in cls.image_paths:
        nrof_images_total += 1
        print(nrof_images_total)
        filename = os.path.splitext(os.path.split(image_path)[1])[0]
        # temp = int(filename)
        # temp = temp + 1000
        # temp = str(temp)
        output_filename = os.path.join(output_class_dir, filename + '.png')
        print(image_path)
        if not os.path.exists(output_filename):
            try:
                img = cv2.imread(image_path)
            except (IOError, ValueError, IndexError) as e:
                errorMessage = '{}: {}'.format(image_path, e)
                print(errorMessage)
            else:
                # if img.ndim < 2:
                #     print('Unable to align "%s"' % image_path)
                #     # text_file.write('%s\n' % (output_filename))
                #     continue
                # if img.ndim == 2:
                #     img = facenet.to_rgb(img)
                # img = img[:, :, 0:3]
                # scaled = misc.imresize(img, (160, 160), interp='bilinear')
                # copyimage = scaled
                for i in range(5):
                    output_filename = os.path.join(output_class_dir, str(i+ random.randint(1000, 10000) ) + '.png')
                    random_angle = np.random.randint(-15, 15)
                    # img.rotate(random_angle)
                    rotated = rotate(img, random_angle)
                    cv2.imwrite(output_filename, rotated)
                random_factor = np.random.randint(8, 12) / 10.  # 随机因子
                image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
                color_image = ImageEnhance.Color(image).enhance(random_factor)  # 调整图像的饱和度
                output_filename = os.path.join(output_class_dir, str(random.randint(1000, 10000)) + '.png')
                imgs = cv2.cvtColor(np.asarray(color_image), cv2.COLOR_RGB2BGR)
                cv2.imwrite(output_filename, imgs)
                random_factor = np.random.randint(8, 12) / 10.  # 随机因子
                image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
                brightness_image = ImageEnhance.Brightness(color_image).enhance(random_factor)# 调整图像的亮度
                output_filename = os.path.join(output_class_dir, str(random.randint(1000, 10000)) + '.png')
                imgs = cv2.cvtColor(np.asarray(brightness_image), cv2.COLOR_RGB2BGR)
                cv2.imwrite(output_filename, imgs)
                random_factor = np.random.randint(8, 12) / 10.  # 随机因子
                image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
                contrast_image = ImageEnhance.Contrast(brightness_image).enhance(random_factor)  # 调整图像对比度
                output_filename = os.path.join(output_class_dir, str(random.randint(1000, 10000)) + '.png')
                imgs = cv2.cvtColor(np.asarray(contrast_image), cv2.COLOR_RGB2BGR)
                cv2.imwrite(output_filename, imgs)
                random_factor = np.random.randint(8, 12) / 10.  # 随机因子
                image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
                color_image_ruidu = ImageEnhance.Sharpness(contrast_image).enhance(random_factor)## 调整图像锐度
                output_filename = os.path.join(output_class_dir, str(random.randint(1000, 10000)) + '.png')
                imgs = cv2.cvtColor(np.asarray(color_image_ruidu), cv2.COLOR_RGB2BGR)
                cv2.imwrite(output_filename, imgs)
                # random_factor = np.random.randint(8, 12) / 10.  # 随机因子
                # brightness_image = ImageEnhance.Brightness(color_image).enhance(random_factor)  # 调整图像的亮度
                # random_factor = np.random.randint(8, 12) / 10.  # 随机因1子
                # contrast_image = ImageEnhance.Contrast(brightness_image).enhance(random_factor)  # 调整图像对比度
                # random_factor = np.random.randint(8, 10) / 10.  # 随机因子
                # # scaled = cv2.resize(img,(160,160),interpolation=cv2.INTER_CUBIC)
                # cv2.imwrite(output_filename, scaled)
                # results = align.detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
