import cv2

import time

if __name__ == '__main__':

    # cv2.NamedWindow("camera", 1)
    # capture = cv.VideoCapture(0)            #开启摄像头
    video_capture = cv2.VideoCapture(1)  # 打开一个视频文件
    # video_capture2 = cv2.VideoCapture(2)  # 打开一个视频文件
    # video_capture3 = cv2.VideoCapture(3)  # 打开一个视频文件
    # video_capture3.set(3, 100)
    # video_capture3.set(4, 100)
    num = 0
    while True:
        ret, frame = video_capture.read()
        # ret, frame2 = video_capture2.read()
        # ret, frame3 = video_capture3.read()

        cv2.imshow("camera", frame)
        # cv2.imshow("camera2", frame2)
        # filename = "saveimages/frmaess.jpg"
        # cv2.imwrite(filename, frame3)
        # cv2.imshow("camera3", frame3)

        key = cv2.waitKey(10)
        if key == 27:
            break
        if key == ord(' '):
            num = num + 1
            filename = "saveimages/frmaes_%s.jpg" % num
            cv2.imwrite(filename, frame)

    video_capture.release()
    cv2.DestroyWindow("camera")
