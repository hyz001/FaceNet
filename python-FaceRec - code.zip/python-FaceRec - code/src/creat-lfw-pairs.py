import os


def file_name(file_dir):
    floder = []
    A = []
    B = []
    dirs = os.listdir(file_dir)#files表示文件名，dirs可以表示为文件夹的名字
    for dir in dirs:
        print(dir)
        # floder.append(dir)
        # A.append(1)
        # B.append(1)
        for root, dirs, files in os.walk(file_dir + '\\' + dir):
            if len(files) >= 10:
                floder.append(dir)
                A.append(2)
                B.append(8)
            # if len(files) >= 4:
            #     floder.append(dir)
            #     A.append(0)
            #     A.append(1)
            #     A.append(2)
            #     A.append(3)
            #     B.append(0)
            #     B.append(1)
            #     B.append(2)
            #     B.append(3)
            # if len(files) >= 6:
            #     floder.append(dir)
            #     A.append(0)
            #     A.append(1)
            #     A.append(2)
            #     A.append(3)
            #     A.append(4)
            #     A.append(5)
            #     B.append(0)
            #     B.append(1)
            #     B.append(2)
            #     B.append(3)
            #     B.append(4)
            #     B.append(5)
            # if len(files) >= 6:
            #     floder.append(dir)
            #     A.append(4)
            #     B.append(5)

            # for file in files:
            #     print(file)
                # os.path.join(root, file)

        # if os.path.splitext(file)[1] == '.png':
        #     # L.append(os.path.join(root, file))
        #     L.append(file)
    return floder,A,B

data_dir = 'K:/facedatas/1'
i, m, n = file_name(data_dir)
f = open('demo.txt', 'w')
# i, m, n = file_name()
for j in range(len(i)):
    # f.write(str(i[j]) + " " +  str(m[j]) + " " + str(i[j+11]) + " " + str(n[j])+"\n")
    # f.write(str(i[j]) + " " + str(m[j + 2]) + " " + str(i[j + 3]) + " " + str(n[j]) + "\n")
    # f.write(str(i[j]) + " " + str(m[j + 4]) + " " + str(i[j + 5]) + " " + str(n[j]) + "\n")
    f.write(str(i[j]) + " " + str(m[j]) + " " + str(n[j]) + "\n")
f.close()